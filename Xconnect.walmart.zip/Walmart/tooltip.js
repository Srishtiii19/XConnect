document.addEventListener('DOMContentLoaded', () => {
    const tooltip = document.getElementById('tooltip');
    const states = document.querySelectorAll('path');

    // Example data structure mapping state names to export values
    const exportValues = {
        'Andaman and Nicobar Islands': '13.1K',
        'Andhra Pradesh': '916K',
        'Arunachal Pradesh': '14.1K',
        'Assam': '533K',
        'Bihar': '1.14M',
        'Chandigarh': '43.1K',
        'Chhattisgarh': '399K',
        'DNHDD': '20.2K',
        'Delhi': '685K',
        'Goa': '56.5K',
        'Gujarat': '1.99M',
        'Haryana': '916K',
        'Himachal Pradesh': '170K',
        'Jammu and Kashmir': '435K',
        'Jharkhand': '479K',
        'Karnataka': '1.60M',
        ' Kerala': '663K',
        ' Ladakh': '11.2K',
        'Lakshadweep': '969',
        'Madhya Pradesh': '1.35M',
        'Maharashtra': '4.64M',
        'Manipur': '73.6K',
        'Meghalaya': '24K',
        'Mizoram': '24.5K',
        'Nagaland': '25.8K',
        'Orrisa': '869K',
        'Puducherry': '40.7K',
        'Punjab': '1.08M',
        'Rajasthan': '2.02M',
        'Sikkim': '11.4K',
        'Tamil Nadu': '2.78M',
        'Telangana': '987K',
        'Tripura': '62.1K',
        'Uttar Pradesh': '2.68M',
        'Uttarakhand': '276K',
        'West Bengal': '1.17M',
        'Kerala':'663K'
        // Add all state names and their corresponding export values here
    };

    states.forEach(state => {
        state.addEventListener('mouseenter', (event) => {
            const stateName = event.target.getAttribute('name');
            const exportValue = exportValues[stateName] || 'N/A'; // Default to 'N/A' if no value found

            tooltip.innerHTML = `<div class="title">${stateName}</div><div class="value">${exportValue}</div>`;
            tooltip.classList.add('show');
        });

        state.addEventListener('mousemove', (event) => {
            tooltip.style.left = event.pageX + 10 + 'px';
            tooltip.style.top = event.pageY + 10 + 'px';
        });

        state.addEventListener('mouseleave', () => {
            tooltip.classList.remove('show');
        });
    });
});