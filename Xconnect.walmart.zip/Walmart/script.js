const chatInput = document.querySelector(".chat-input textarea");
const sendChatBtn = document.querySelector(".chat-input span");
const chatbox = document.querySelector(".chatbox");
const chatbotToggler = document.querySelector(".chatbot-toggler");
const chatbotCloseBtn = document.querySelector(".close-btn ");

let userMessage;
const API_KEY = "sk-proj-gSrtLde57O2NNIb2ltnnT3BlbkFJuvB3V5eapGobJxCnhvlo";
const inputInitHeight = chatInput.scrollHeight;

const createChatLi = (message, className, sender) => {
  // Create a chat <li> element with passed message, className, and sender
  const chatLi = document.createElement("li");
  chatLi.classList.add("chat", className);
  let chatContent = "";

  if (sender === "user") {
    // Outgoing message from user
    chatContent = `<p>${message}</p>`;
    chatLi.style.textAlign = "right"; // Align to the right
    // chatLi.style.backgroundColor = "#ddd"; // Light background color
  } else {
    // Incoming message from bot
    chatContent = `<span class="material-symbols-outlined">smart_toy</span> <p>${message}</p>`;
  }

  chatLi.innerHTML = chatContent;
  return chatLi;
};

const fixedResponses = {
  "msme exporter count in delhi": "There are about 25,000 MSME exporters in Delhi.",
  "how are you": "EcoEats is a tech-driven platform combating food waste and promoting sustainability. Users engage in activities like food donation and composting organic waste, facilitated by innovative partnerships and technologies. Green tokens incentivize eco-friendly actions, fostering community participation and accountability. With a focus on transparency, EcoEats empowers users to trust in its integrity and contribute to environmental conservation efforts. Through these initiatives, EcoEats empowers individuals to make a tangible impact on building a sustainable future."

  // Add more questions and answers here
};

const generateResponse = (incomingChatLi) => {
  const API_URL = "https://api.openai.com/v1/chat/completions";
  const messageElement = incomingChatLi.querySelector("p");

  const requestOptions = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${API_KEY}`,
    },
    body: JSON.stringify({
      model: "gpt-3.5-turbo",  // Uncomment and replace with your model if using GPT-3.5
      messages: [
        {
          role: "user",
          content: userMessage,
        },
      ],
    }),
  };

  // Send POST request API ,get response
  fetch(API_URL, requestOptions)
    .then((res) => res.json())
    .then((data) => {
      messageElement.textContent = data.choices[0].message.content;
    })
    .catch((error) => {
      messageElement.classList.add("error");
      messageElement.textContent = "Oops! Something went wrong. Please try again.";
    })
    .finally(() => chatbox.scrollTo(0, chatbox.scrollHeight));
};

const handleChat = () => {
  userMessage = chatInput.value.trim().toLowerCase();
  if (!userMessage) return;
  chatInput.value = "";

  const fixedAnswer = fixedResponses[userMessage];
  if (fixedAnswer) {
    // Found a fixed answer, display it directly
    const outgoingChatLi = createChatLi(userMessage, "outgoing", "user");
    const incomingChatLi = createChatLi(fixedAnswer, "incoming", "bot");
    chatbox.appendChild(outgoingChatLi);
    chatbox.appendChild(incomingChatLi);
    chatbox.scrollTo(0, chatbox.scrollHeight);
    return; // Exit the function to prevent triggering GPT-3.5
  }

  // No fixed answer, use GPT-3.5 integration
  console.log("No fixed answer found, using GPT-3.5:", userMessage);
  const incomingChatLi = createChatLi("Thinking...", "incoming", "bot");
  chatbox.appendChild(incomingChatLi);
  chatbox.scrollTo(0, chatbox.scrollHeight);
  generateResponse(incomingChatLi);
};

chatInput.addEventListener("input", () => {
  // Adjust the height of the input textarea based on its content
  chatInput.style.height = `${inputInitHeight}px`;
  chatInput.style.height = `${chatInput.scrollHeight}px`;
});

sendChatBtn.addEventListener("click",handleChat);
chatbotCloseBtn.addEventListener("click",() => document.body.classList.remove("show-chatbot"));
chatbotToggler.addEventListener("click",() => document.body.classList.toggle("show-chatbot"));

  